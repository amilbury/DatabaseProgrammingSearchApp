﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; //handles all MySql classes
using System.Configuration; //for app.config having connection string
using System.IO; //for files
using System.Data.SqlTypes;
using MySqlX.XDevAPI.Relational;


namespace Lab4
{
    /*
    Name:Aaron Milbury
    Date:June 4th 2023
    Description:This lab we connected to a database through code and performed multiple different kinds of queries, aggregations
    and crud operations.
     */
    public partial class Form1 : Form
    {
        private StreamWriter MilburyLog = new StreamWriter("MilburyLog.txt");
        static string connStr = ConfigurationManager.ConnectionStrings["empdb"].ConnectionString;

        //create connection
        MySqlConnection conn = new MySqlConnection(connStr);
        public Form1()
        {

            InitializeComponent();
        }

        //Call all the functions necessary for form load and start the Log
        private void Form1_Load(object sender, EventArgs e)
        {
            MilburyLog.WriteLine("Command: Aaron Milbury");
            MilburyLog.WriteLine("Command: " + DateTime.Now.ToString());
            OpenConnection();
            RunScript();
            DeleteTable();
            ViewTables();
            DateTimes();
            Titles();
            DateFixer();
            radRemoveTitle.Checked = true;
            radDept.Checked = true;
        }
        /*
        Name:OpenConnection
        Sent:NA
        Returns:Void
        Description:Opens the connection to the database
         */
        private void OpenConnection()
        {

            try
            {
                conn.Open();
                //MessageBox.Show(conn.ToString());
            }
            catch (Exception ex)
            {
                Error(ex);
            }
        }
        /*
        Name:RunScript
        Sent:NA
        Returns:Void
        Description:Run the MySql script
         */
        private void RunScript()
        {
            string script = File.ReadAllText("emp.sql");

            try
            {
                MySqlCommand cmd = new MySqlCommand(script, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Error(ex);
            }

        }
        /*
        Name:DeleteTable
        Sent:NA
        Returns:Void
        Description:Deletes the 'families' table from the emp database
         */
        private void DeleteTable()
        {
            string deleteQuery = "drop table if exists families";
            MySqlCommand deleteCom = new MySqlCommand(deleteQuery, conn);
            try
            {
                deleteCom.ExecuteNonQuery();
                LogQuery(deleteQuery);
            }
            catch (Exception ex)
            {
                Error(ex);
            }
        }
        /*
        Name:ViewTables
        Sent:NA
        Returns:Void
        Description:Loops through the tables and adds them to the listbox
         */
        private void ViewTables()
        {
            string tableCom = "show tables";
            MySqlCommand tables = new MySqlCommand(tableCom, conn);

            try
            {
                MySqlDataReader reader = tables.ExecuteReader();

                while (reader.Read())
                {
                    //MessageBox.Show("Test");
                    string table = reader.GetString(0);
                    lstTables.Items.Add(table);
                }
                reader.Close();
                LogQuery(tableCom);
            }
            catch (Exception ex)
            {
                Error(ex);
            }

        }

        /*
        Name:DateTimes
        Sent:NA
        Returns:Void
        Description:Grab the min and max hire dates and add each value to their respective date time picker
         */
        private void DateTimes()
        {
            //Populate the date time pickers
            //Query for the most recent date
            string earliestDateCom = "Select min(hire_date)" +
                "from employees";
            string latestDateCom = "Select max(hire_date)" +
                "from employees";

            MySqlCommand earliestDate = new MySqlCommand(earliestDateCom, conn);
            MySqlCommand latestDate = new MySqlCommand(latestDateCom, conn);
            try
            {
                //string earlyDate = earliestDate
                DateTime startDate = (DateTime)earliestDate.ExecuteScalar();

                dtpStartDate.Value = startDate;
                dtpStartDate.Format = DateTimePickerFormat.Custom;
                dtpStartDate.CustomFormat = "M/d/yyyy";
                LogQuery(earliestDateCom);
                //MessageBox.Show("test");
            }
            catch(Exception ex)
            {
                Error(ex);
            }
            try
            {
                DateTime endDate = (DateTime)latestDate.ExecuteScalar();
                dtpEndDate.Value = endDate;
                dtpEndDate.Format = DateTimePickerFormat.Custom;
                dtpEndDate.CustomFormat = "M/d/yyyy";
                LogQuery(latestDateCom);
            }
            catch(Exception ex)
            {
                Error(ex);
            }




            
        }
        /*
        Name:Titles
        Sent:NA
        Returns:Void
        Description:Add the titles from the titles table to the titles listbox
         */
        private void Titles()
        {
            string titles = "Select distinct title from titles order by title";
            MySqlCommand titleCom = new MySqlCommand(titles, conn);
            try
            {
                MySqlDataReader reader = titleCom.ExecuteReader();

                while(reader.Read())
                {
                    //MessageBox.Show("Test");
                    string table = reader.GetString(0);
                    lstTitles.Items.Add(table);
                }

                reader.Close();
                LogQuery(titles);
            }
            catch (Exception ex)
            {
                Error(ex);
            }
        }
        /*
        Name:DateFixer
        Sent:NA
        Returns:Void
        Description:Fix the dates for the given tables so there will no longer be any dates that are ahead of today
         */
        private void DateFixer()
        {
            //Query employee manager salaries and titles tables to fix the dates so that the wrong ones are now today
            string today = DateTime.Now.ToString("yyyy-MM-dd");
            string updateEmp = "update dept_emp set to_date = '" + today + "'where to_date > '" + today + "'";
            string updateManager = "update dept_manager set to_date = '" + today + "'where to_date > '" + today + "'";
            string updateSalaries = "update salaries set to_date = '" + today + "'where to_date > '" + today + "'";
            string updateTitles = "update titles set to_date = '" + today + "'where to_date > '" + today + "'";

            MySqlCommand updateEmpCom = new MySqlCommand(updateEmp, conn);
            MySqlCommand updateManagerCom = new MySqlCommand(updateManager, conn);
            MySqlCommand updateSalariesCom = new MySqlCommand(updateSalaries, conn);
            MySqlCommand updateTitlesCom = new MySqlCommand(updateTitles, conn);

            try
            {
                updateEmpCom.ExecuteNonQuery();
                updateManagerCom.ExecuteNonQuery();
                updateSalariesCom.ExecuteNonQuery();
                updateTitlesCom.ExecuteNonQuery();
                LogQuery(updateEmp);
                LogQuery(updateManager);
                LogQuery(updateSalaries);
                LogQuery(updateTitles);
            }
            catch(Exception ex)
            {
                Error(ex);
            }
        }

        /*
        Name:Error
        Sent:Exception
        Returns:Void
        Description:Basic function to display a message box with the error message and close the form
         */
        private void Error(Exception ex)
        {
            MessageBox.Show(ex.Message +"\nClosing the form", "Error");
            Close();
        }

        //close the connection string and the log
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Close connection
            conn.Close();
            MilburyLog.Close();
        }

        //Run a query displaying the data for each given table based on which table is selected in the list box
        private void lstTables_SelectedIndexChanged(object sender, EventArgs e)
        {

            if(lstTables.SelectedItems.Count > 0)
            {
                cboSearch.SelectedIndex = -1;
                //Query for all records in the specific table
                string tableQuery = "Select * from " + lstTables.SelectedItem.ToString();
                MySqlCommand tableCom = new MySqlCommand(tableQuery, conn);
                DataTable titleTable = new DataTable();
                BindingSource bs = new BindingSource();
                bs.DataSource = titleTable;
                try
                {
                    titleTable.Load(tableCom.ExecuteReader());
                    dgvResults.DataSource = bs;
                    bdnDataGrid.BindingSource = bs;
                    bdnDataGrid.Show();
                    LogQuery(tableQuery);
                }
                catch (Exception ex)
                {
                    Error(ex);
                }
            }
        }

        //Search the database employees table for either their average salaries or which employees were hired between the dates
        //In the date time picker
        private void cboSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboSearch.Focused)
            {
                lstTables.ClearSelected();
            }

            
            if(cboSearch.SelectedIndex == 0)
            {
                //search the database for the average salaries of all employees
                string avgSalaries = "select e.emp_no, concat(e.last_name,', ', e.first_name) as Name, " +
                    "concat('$',format(avg(s.salary), 2)) as 'Avg Salary' from employees e " +
                    "inner join salaries s using (emp_no) " +
                    "group by e.emp_no " +
                    "order by e.last_name";
                MySqlCommand salaryCom = new MySqlCommand(avgSalaries, conn);
                DataTable table = new DataTable();
                BindingSource bs = new BindingSource();
                bs.DataSource = table;
                try
                {
                    table.Load(salaryCom.ExecuteReader());
                    dgvResults.DataSource = bs;
                    bdnDataGrid.BindingSource = bs;
                    LogQuery(avgSalaries);
                    bdnDataGrid.Show();
                }
                catch (Exception ex)
                {
                    Error(ex);
                }

            }
            //Search if the employees date of hiring was between the two date time pickers values
            if(cboSearch.SelectedIndex == 1)
            {
                //Query for hire date
                string hiredDate = "select e.emp_no, concat(e.last_name,', ', e.first_name) as Name, " +
                "hire_date from employees e " +
                "where (hire_date between '" + dtpStartDate.Value +"'and '"+ dtpEndDate.Value +"')"+
                "order by e.hire_date";
                MySqlCommand hiredCom = new MySqlCommand(hiredDate, conn);
                DataTable table = new DataTable();
                BindingSource bs = new BindingSource();
                bs.DataSource = table;
                try
                {
                    table.Load(hiredCom.ExecuteReader());
                    dgvResults.DataSource = bs;
                    bdnDataGrid.BindingSource = bs;
                    LogQuery(hiredDate);
                    bdnDataGrid.Show();
                }
                catch (Exception ex)
                {
                    Error(ex);
                }
            }
        }

        //Enable / disable dept and titles group boxes based on which radio button was checked
        private void radDept_CheckedChanged(object sender, EventArgs e)
        {
            if (radDept.Checked)
            {
                grpDept.Enabled = true;
                grpTitles.Enabled = false;
                lstEmpNo.Items.Clear();
                lstTitles.SelectedIndex = -1;
            }
            else
            {
                grpDept.Enabled = false;
                grpTitles.Enabled = true;
            }
        }

        //Add a department to the departments table
        private void btnAddDept_Click(object sender, EventArgs e)
        {
            string deptNum = "d0" + nudDept.Value.ToString();
            string name = txtDept.Text;
            if (name.Length >= 5)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to add a new department?", 
                    "Confirm Addition", MessageBoxButtons.YesNo);
                if(dialogResult == DialogResult.Yes)
                {
                    string add = "INSERT INTO departments (dept_no, dept_name)" +
                        $" values ('{deptNum}', '{name}')";
                    try
                    {
                        //MessageBox.Show(add);
                        MySqlCommand addCom = new MySqlCommand(add, conn);
                        //MessageBox.Show(addCom.ToString());
                        addCom.ExecuteNonQuery();
                        MessageBox.Show("Confirmation: 1 record(s) added", "Additon Completed");
                        LogQuery(add);
                    }
                    catch(Exception ex)
                    {
                        Error(ex);
                    }
                }
            }
            else
            {
                MessageBox.Show("Department name too short\n" +
                    "Please make sure the departments name is at least 5 charachters",
                    "Error");
            }
        }
        //delete a title from the title table
        private void btnDeleteTitle_Click(object sender, EventArgs e)
        {
            if (lstEmpNo.SelectedIndex > -1 && lstTitles.SelectedIndex > -1)
            {
                string delete = "delete from titles where emp_no = '" + lstEmpNo.SelectedItem.ToString() + "'" +
                    "and title = '" + lstTitles.Text+ "'";
                MySqlCommand deleteCom = new MySqlCommand(delete, conn);
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete based on the emp_no and title " +
                    "selected?", "Confirm Deletion", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        deleteCom.ExecuteNonQuery();
                        MessageBox.Show("Confirmation: 1 record(s) deleted", "Deletion Completed");
                        //lstEmpNo.Items.Clear();
                        PopulateEmpNum();
                        LogQuery(delete);
                    }
                    catch (Exception ex)
                    {
                        Error(ex);
                    }
                }
            }
        }

        /*
        Name:PopulateEmpNum
        Sent:NA
        Returns:Void
        Description:Loop through the employee numbers and populate the list box with their values
         */
        private void PopulateEmpNum()
        {
            //MessageBox.Show("Test");
            if(lstTitles.SelectedIndex != -1)
            {
                lstEmpNo.Items.Clear();

                string title = lstTitles.SelectedItem.ToString();
                string titleQuery = "Select emp_no from titles where title = '" + title + "'";
                MySqlCommand titleCom = new MySqlCommand(titleQuery, conn);
                try
                {
                    MySqlDataReader reader = titleCom.ExecuteReader();
                    while (reader.Read())
                    {
                        lstEmpNo.Items.Add(reader.GetString(0));
                    }
                    reader.Close();
                    LogQuery(titleQuery);
                }
                catch (Exception ex)
                {
                    Error(ex);
                }

            }
        }
        /*
        Name:LogQuery
        Sent:NA
        Returns:Void
        Description:log all queries ran to the text file
         */
        private void LogQuery(string query)
        {
            MilburyLog.WriteLine("Command: " + query);
        }
        //query database for the employee number based on the selected table
        private void lstTitles_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateEmpNum();
        }
    }
}
